/* 
 Alan Trevino
 September 15, 2013
Programming Languages 1
This program will display my name, adress with city,
state and zip, my telephone number,
and my college major
*/


#include <iostream>
using namespace std;

int main()
{
//name
cout<<"My name is Alan Trevino. \n";

//addresss, city, state, zip
cout<<"I live on 12626 Blanco Rd Apt 1403,\n";
cout<<"San Antonio, Texas, 78216.\n";

//telephone number
cout<<"My cell number is 956.286.2526.\n";

//college major
cout<<"I am a Computer Information Systems major.\n";

return 0;
}
